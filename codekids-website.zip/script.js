﻿// Navigation
function showSection(sectionId) {
    // Hide all sections
    document.querySelectorAll('.section').forEach(section => {
        section.classList.remove('active');
    });
    
    // Show selected section
    document.getElementById(sectionId).classList.add('active');
    
    // Update nav buttons
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.classList.remove('active');
        if (btn.dataset.section === sectionId) {
            btn.classList.add('active');
        }
    });
}

// Initialize navigation
document.querySelectorAll('.nav-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        showSection(btn.dataset.section);
    });
});

// Lesson cards
document.querySelectorAll('.lesson-card').forEach(card => {
    card.querySelector('.btn-lesson').addEventListener('click', () => {
        showSection('playground');
    });
});

// Code Playground Functions
const canvas = document.getElementById('canvas-output');
const ctx = canvas.getContext('2d');
const textOutput = document.getElementById('text-output');

// Clear canvas
function clearCanvas() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    textOutput.textContent = '';
}

// Drawing functions available in playground
window.drawCircle = function(x, y, radius, color = 'blue') {
    ctx.beginPath();
    ctx.arc(x, y, radius, 0, 2 * Math.PI);
    ctx.fillStyle = color;
    ctx.fill();
    ctx.strokeStyle = 'black';
    ctx.lineWidth = 2;
    ctx.stroke();
};

window.drawSquare = function(x, y, size, color = 'blue') {
    ctx.fillStyle = color;
    ctx.fillRect(x - size/2, y - size/2, size, size);
    ctx.strokeStyle = 'black';
    ctx.lineWidth = 2;
    ctx.strokeRect(x - size/2, y - size/2, size, size);
};

window.drawStar = function(x, y, radius, color = 'yellow') {
    ctx.save();
    ctx.translate(x, y);
    ctx.beginPath();
    for (let i = 0; i < 5; i++) {
        const angle = (i * 4 * Math.PI) / 5 - Math.PI / 2;
        const px = Math.cos(angle) * radius;
        const py = Math.sin(angle) * radius;
        if (i === 0) {
            ctx.moveTo(px, py);
        } else {
            ctx.lineTo(px, py);
        }
    }
    ctx.closePath();
    ctx.fillStyle = color;
    ctx.fill();
    ctx.strokeStyle = 'black';
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.restore();
};

window.sayHello = function(name = 'Friend') {
    const message = `Hello, ${name}! 👋`;
    textOutput.textContent += message + '\n';
    return message;
};

window.calculate = function(a, b, operation = '+') {
    let result;
    switch(operation) {
        case '+':
            result = a + b;
            break;
        case '-':
            result = a - b;
            break;
        case '*':
            result = a * b;
            break;
        case '/':
            result = b !== 0 ? a / b : 'Cannot divide by zero!';
            break;
        default:
            result = 'Unknown operation';
    }
    const message = `${a} ${operation} ${b} = ${result}`;
    textOutput.textContent += message + '\n';
    return result;
};

// Run code from playground
document.getElementById('run-code').addEventListener('click', () => {
    const codeInput = document.getElementById('code-input').value;
    runCode(codeInput);
});

// Execute code safely
function runCode(code) {
    clearCanvas();
    textOutput.textContent = '';
    
    try {
        // Create a safe execution context
        const safeCode = `
            (function() {
                ${code}
            })();
        `;
        eval(safeCode);
    } catch (error) {
        textOutput.textContent = 'Error: ' + error.message;
        textOutput.style.color = '#ef4444';
    }
}

// Challenge checking
let completedChallenges = JSON.parse(localStorage.getItem('completedChallenges') || '[]');

function checkChallenge(challengeNum) {
    const challengeCard = document.querySelector(`[data-challenge="${challengeNum}"]`);
    const codeInput = challengeCard.querySelector('.challenge-code').value;
    const feedback = document.getElementById(`feedback-${challengeNum}`);
    
    // Clear previous output
    clearCanvas();
    textOutput.textContent = '';
    
    let passed = false;
    let message = '';
    
    try {
        // Execute the code
        eval(codeInput);
        
        // Check based on challenge number
        switch(challengeNum) {
            case 1:
                // Check if a red circle was drawn
                const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
                let hasRed = false;
                for (let i = 0; i < imageData.data.length; i += 4) {
                    if (imageData.data[i] > 200 && imageData.data[i+1] < 100 && imageData.data[i+2] < 100) {
                        hasRed = true;
                        break;
                    }
                }
                if (hasRed) {
                    passed = true;
                    message = '🎉 Awesome! You drew a red circle!';
                } else {
                    message = '❌ Try drawing a red circle using drawCircle(250, 250, 100, "red")';
                }
                break;
                
            case 2:
                // Check if multiple shapes were drawn
                const imageData2 = ctx.getImageData(0, 0, canvas.width, canvas.height);
                let pixelCount = 0;
                for (let i = 0; i < imageData2.data.length; i += 4) {
                    if (imageData2.data[i] !== 255 || imageData2.data[i+1] !== 255 || imageData2.data[i+2] !== 255) {
                        pixelCount++;
                    }
                }
                if (pixelCount > 5000) {
                    passed = true;
                    message = '🎉 Great job! You drew multiple shapes!';
                } else {
                    message = '❌ Try drawing more shapes! Use drawSquare, drawStar, and drawCircle with different colors.';
                }
                break;
                
            case 3:
                // Check if a loop was used (look for pattern of circles)
                const imageData3 = ctx.getImageData(0, 0, canvas.width, canvas.height);
                let pixelCount3 = 0;
                for (let i = 0; i < imageData3.data.length; i += 4) {
                    if (imageData3.data[i] !== 255 || imageData3.data[i+1] !== 255 || imageData3.data[i+2] !== 255) {
                        pixelCount3++;
                    }
                }
                // Check if code contains 'for' keyword
                if (codeInput.includes('for') && pixelCount3 > 3000) {
                    passed = true;
                    message = '🎉 Excellent! You used a loop to create a pattern!';
                } else {
                    message = '❌ Try using a for loop! Example: for (let i = 0; i < 5; i++) { drawCircle(100 + i*80, 250, 30, "blue"); }';
                }
                break;
        }
        
    } catch (error) {
        message = '❌ Error: ' + error.message + '. Check your code syntax!';
    }
    
    // Show feedback
    feedback.textContent = message;
    feedback.className = 'challenge-feedback ' + (passed ? 'success' : 'error');
    
    // Update progress if challenge passed
    if (passed && !completedChallenges.includes(challengeNum)) {
        completedChallenges.push(challengeNum);
        localStorage.setItem('completedChallenges', JSON.stringify(completedChallenges));
        updateProgress();
        // Celebrate!
        setTimeout(() => celebrate(), 100);
    }
    
    // Clear canvas after checking
    setTimeout(() => {
        clearCanvas();
    }, 3000);
}

function updateProgress() {
    const total = 3;
    const completed = completedChallenges.length;
    const progressPercent = (completed / total) * 100;
    
    document.getElementById('progress-fill').style.width = progressPercent + '%';
    document.getElementById('progress-count').textContent = completed;
}

// Initialize progress on load
updateProgress();

// Allow Enter key to run code in playground
document.getElementById('code-input').addEventListener('keydown', (e) => {
    if (e.ctrlKey && e.key === 'Enter') {
        document.getElementById('run-code').click();
    }
});

// Add some example code suggestions
document.querySelectorAll('.challenge-code').forEach(textarea => {
    textarea.addEventListener('focus', function() {
        if (this.value === '// Your code here' || this.value.trim() === '') {
            this.value = '';
        }
    });
});

// Add celebration animation when challenge is completed
function celebrate() {
    const colors = ['#6366f1', '#ec4899', '#f59e0b', '#10b981'];
    for (let i = 0; i < 20; i++) {
        setTimeout(() => {
            const confetti = document.createElement('div');
            confetti.style.position = 'fixed';
            confetti.style.left = Math.random() * 100 + '%';
            confetti.style.top = '-10px';
            confetti.style.width = '10px';
            confetti.style.height = '10px';
            confetti.style.background = colors[Math.floor(Math.random() * colors.length)];
            confetti.style.borderRadius = '50%';
            confetti.style.pointerEvents = 'none';
            confetti.style.zIndex = '9999';
            confetti.style.animation = 'fall 3s linear forwards';
            document.body.appendChild(confetti);
            
            setTimeout(() => confetti.remove(), 3000);
        }, i * 100);
    }
}

// Add CSS animation for confetti
const style = document.createElement('style');
style.textContent = `
    @keyframes fall {
        to {
            transform: translateY(100vh) rotate(360deg);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

// Initialize - show home section by default
showSection('home');
